import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Loader2, ChevronLeft, ChevronRight, Save, AlertCircle, RotateCw } from 'lucide-react';
import { applicationCaseContext, applicationCaseSaveProgress, applicationCaseTransition } from '@/lib/applicationCaseApi';
import { confirmApplicationApi, bulkAnswers } from '@/lib/visaApi';
import { base44 } from '@/api/base44Client';
import WizardProgress from '@/components/wizard/WizardProgress';
import { StepTravel, StepTraveler, StepJourney, StepEligibility, StepRequirements, StepTravelerInfo, StepMaterialDetails, StepDocuments, StepReview, StepPayment, StepSubmission, StepConfirmation } from '@/components/wizard/WizardSteps';

export default function VisaWizard() {
  const { id } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const ctxQ = useQuery({ queryKey: ['wizard-context', id], queryFn: () => applicationCaseContext(id), enabled: !!id, retry: false });
  const ctx = ctxQ.data;
  const caseRow = ctx?.case;
  const cv = ctx?.case_view;

  const steps = ctx?.steps || [];
  const savedIndex = (typeof cv?.wizard?.step_index === 'number' && cv.wizard.step_index < steps.length) ? cv.wizard.step_index : 0;
  const activeIndex = Math.max(0, steps.findIndex((s) => s.id === ctx?.active_step));
  // Saved wizard progress is only a convenience cursor; case_state remains the
  // authority. Older builds could save Review while the case was still
  // DOCUMENTS_REQUIRED, producing the contradictory screenshots. Clamp those
  // milestone states to the backend's active step on resume.
  const forceAuthoritativeStep = ['DRAFT', 'INTAKE', 'ELIGIBILITY_REVIEW', 'DOCUMENTS_REQUIRED', 'DOCUMENTS_REVIEW'].includes(cv?.state || caseRow?.case_state);
  const stepIndex0 = forceAuthoritativeStep ? activeIndex : savedIndex;
  const [stepIndex, setStepIndex] = useState(0);
  const [hydratedCaseId, setHydratedCaseId] = useState(null);
  const [form, setForm] = useState(cv?.wizard?.form || {});
  const [confirmed, setConfirmed] = useState(false);
  const [passportReady, setPassportReady] = useState(!!cv?.wizard?.form?.passport?.confirmed);
  const [documentsReady, setDocumentsReady] = useState(false);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (ctx && hydratedCaseId !== id) {
      setStepIndex(stepIndex0);
      setForm(cv?.wizard?.form || {});
      setHydratedCaseId(id);
    }
  }, [ctx, id, hydratedCaseId, stepIndex0, cv?.wizard?.form]);

  const currentStep = steps[stepIndex];
  const stateNow = cv?.state || caseRow?.case_state;

  const blockedStepId = useMemo(() => {
    if (!ctx) return null;
    if (ctx.next_action?.blocked) return currentStep?.id;
    return null;
  }, [ctx, currentStep]);

  // Resume once context loads.
  useEffect(() => {
    if (ctx) base44.analytics?.track?.({ eventName: stepIndex0 > 0 ? 'CASE_RESUMED' : 'CASE_STARTED', properties: { case_id: id, step: stepIndex0 } });
  }, [id]);  

  if (ctxQ.isLoading) return <div className="flex h-[60vh] items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-slate-400" /></div>;
  if (ctxQ.isError) return <ErrorState onRetry={() => ctxQ.refetch()} message="We couldn’t load your application. Please try again." />;
  if (!ctx || !caseRow) return <ErrorState onRetry={() => ctxQ.refetch()} message="This application could not be found or you don’t have access." />;

  const isTerminal = ['APPROVED', 'REJECTED', 'CANCELLED', 'EXPIRED', 'COMPLETED'].includes(stateNow);
  const last = stepIndex >= steps.length - 1;
  const isFirst = stepIndex === 0;

  const persist = async (nextIndex, formData) => applicationCaseSaveProgress({ id, step_index: nextIndex, form: formData });

  const fireTransition = async (to) => {
    if (!to || to === stateNow) return null;
    const res = await applicationCaseTransition({ id, to, idempotency_key: `step_${to}_${id}` });
    if (res?.error) throw new Error(res.error);
    return res;
  };

  const onContinue = async () => {
    setError(null);
    if (currentStep?.id === 'travel' && !(passportReady || form?.passport?.confirmed)) { setError('Upload and confirm the passport details before continuing.'); return; }
    if (currentStep?.id === 'documents' && !documentsReady) { setError('We’re still checking the required documents. Resolve any missing or review items before continuing.'); return; }
    if (currentStep?.id === 'review' && !confirmed) { setError('Please confirm the information is accurate before continuing.'); return; }
    setBusy(true);
    try {
      const sid = currentStep?.id;
      let nextIndex = stepIndex + 1;
      const indexOf = (stepId) => steps.findIndex((s) => s.id === stepId);

      if (sid === 'travel') {
        // PassportAutopilot already created/updated the case traveler, so do not
        // make the customer click through a second traveler form plus read-only
        // journey screens. Persist travel first (which refreshes eligibility),
        // enter INTAKE, then jump to the combined Verify stage.
        const verifyIndex = indexOf('eligibility');
        nextIndex = verifyIndex >= 0 ? verifyIndex : Math.min(stepIndex + 1, steps.length - 1);
        await persist(nextIndex, form);
        if (stateNow === 'DRAFT') await fireTransition('INTAKE');
      } else if (sid === 'eligibility') {
        // Journey + eligibility + requirements are rendered together. Once the
        // traveler continues, advance the deterministic case engine through its
        // two internal milestones and land directly on missing documents/review.
        // Save the material application answers (passport/personal fields are
        // auto-filled by PassportAutopilot; travel dates + employment + income
        // are collected here) so the final-review readiness gate has verified
        // answers to check against instead of perma-blocking on never-collected
        // required questions.
        await bulkAnswers(id, {
          'travel.purpose': cv?.snapshot?.purpose || caseRow?.purpose || form?.travel?.purpose || 'tourism',
          'travel.departure_date': form?.travel?.departure || '',
          'travel.return_date': form?.travel?.return || '',
          'employment.status': form?.details?.employment_status || '',
          'financial.annual_income': form?.details?.annual_income || '',
        }).catch(() => {});
        await persist(stepIndex, form);
        const hasRequiredDocs = (ctx.required_docs || []).length > 0;
        if (stateNow === 'INTAKE') {
          await applicationCaseTransition({ id, to: 'ELIGIBILITY_REVIEW', idempotency_key: `step_ELIGIBILITY_REVIEW_${id}` });
          await applicationCaseTransition({ id, to: hasRequiredDocs ? 'DOCUMENTS_REQUIRED' : 'DOCUMENTS_REVIEW', idempotency_key: `step_${hasRequiredDocs ? 'DOCUMENTS_REQUIRED' : 'DOCUMENTS_REVIEW'}_${id}` });
        } else if (stateNow === 'ELIGIBILITY_REVIEW') {
          await applicationCaseTransition({ id, to: hasRequiredDocs ? 'DOCUMENTS_REQUIRED' : 'DOCUMENTS_REVIEW', idempotency_key: `step_${hasRequiredDocs ? 'DOCUMENTS_REQUIRED' : 'DOCUMENTS_REVIEW'}_${id}` });
        }
        const docsIndex = indexOf('documents');
        const reviewIndex = indexOf('review');
        nextIndex = hasRequiredDocs && docsIndex >= 0 ? docsIndex : (reviewIndex >= 0 ? reviewIndex : Math.min(stepIndex + 1, steps.length - 1));
        await persist(nextIndex, form);
      } else if (sid === 'documents') {
        nextIndex = indexOf('review');
        if (nextIndex < 0) nextIndex = Math.min(stepIndex + 1, steps.length - 1);
        await persist(nextIndex, form);
        // Documents move only into review. READY_FOR_SUBMISSION is deliberately
        // impossible here: the backend requires verified documents + traveler
        // confirmation first, so the review step owns that gate.
        if (stateNow === 'DOCUMENTS_REQUIRED') await fireTransition('DOCUMENTS_REVIEW');
      } else if (sid === 'review') {
        await persist(stepIndex, form);
        // Persist the legal/user attestation through the existing final-review
        // engine, then ask the case engine to cross the submission-readiness gate.
        // If documents are still processing or any review finding blocks, either
        // call fails and this wizard stays on Review instead of lying about state.
        await confirmApplicationApi(id);
        if (stateNow === 'DOCUMENTS_REVIEW' || stateNow === 'DOCUMENTS_REQUIRED') await fireTransition('READY_FOR_SUBMISSION');
        nextIndex = stepIndex + 1;
        await persist(nextIndex, form);
      } else {
        await persist(nextIndex, form);
      }

      base44.analytics?.track?.({ eventName: 'WIZARD_STEP_COMPLETED', properties: { case_id: id, step: sid } });
      await qc.invalidateQueries({ queryKey: ['wizard-context', id] });
      setStepIndex(Math.min(nextIndex, steps.length - 1));
    } catch (e) {
        const rs = Array.isArray(e?.reasons) ? e.reasons : (Array.isArray(e?.reason) ? e.reason : null);
        const base = e?.message || 'Something went wrong saving your progress.';
        setError(rs && rs.length ? `${base} — ${rs.slice(0, 5).map((r) => r.message || r.code || r).join('; ')}` : base);
      }
    finally { setBusy(false); }
  };

  const onSubmit = async () => {
    setBusy(true); setError(null);
    try {
      // Submission is a separate, explicit axis. A case must enter
      // SUBMISSION_PENDING before SUBMITTED; payment/confirmation alone never
      // means the provider or government received the application.
      if (stateNow === 'READY_FOR_SUBMISSION') {
        await applicationCaseTransition({ id, to: 'SUBMISSION_PENDING', idempotency_key: `submit_pending_${id}` });
      }
      await applicationCaseTransition({ id, to: 'SUBMITTED', idempotency_key: `submit_${id}` });
      base44.analytics?.track?.({ eventName: 'APPLICATION_SUBMITTED', properties: { case_id: id } });
      await qc.invalidateQueries({ queryKey: ['wizard-context', id] });
      setStepIndex(steps.length - 1);
    } catch (e) { setError(e?.message || 'Submission failed.'); }
    finally { setBusy(false); }
  };

  const onBack = () => { setError(null); setStepIndex(Math.max(0, stepIndex - 1)); };

  const onExit = async () => { await persist(stepIndex, form).catch(() => {}); navigate('/cases'); };

  const renderStep = () => {
    switch (currentStep?.id) {
      case 'travel': return <StepTravel form={form} setForm={setForm} ctx={ctx} caseRow={caseRow} onPassportReady={setPassportReady} />;
      case 'traveler': return <StepTraveler form={form} setForm={setForm} snapshot={cv?.snapshot} />;
      case 'journey': return <StepJourney ctx={ctx} />;
      case 'eligibility': return <div className="space-y-6"><StepJourney ctx={ctx} /><StepEligibility ctx={ctx} /><StepRequirements ctx={ctx} /><StepMaterialDetails form={form} setForm={setForm} /></div>;
      case 'requirements': return <StepRequirements ctx={ctx} />;
      case 'traveler_info': return <StepTravelerInfo form={form} setForm={setForm} />;
      case 'documents': return <StepDocuments ctx={ctx} caseRow={caseRow} onReadyChange={setDocumentsReady} />;
      case 'review': return <StepReview ctx={ctx} form={form} confirmed={confirmed} setConfirmed={setConfirmed} />;
      case 'payment': return <StepPayment ctx={ctx} caseRow={caseRow} />;
      case 'submission': return <StepSubmission ctx={ctx} />;
      case 'confirmation': return <StepConfirmation ctx={ctx} form={form} />;
      default: return null;
    }
  };

  const stageForStep = (stepId) => {
    if (['travel', 'traveler'].includes(stepId)) return 0;
    if (['journey', 'eligibility', 'traveler_info'].includes(stepId)) return 1;
    if (['requirements', 'documents'].includes(stepId)) return 2;
    return 3;
  };
  const customerStages = [
    { id: 'upload', label: 'Upload / Import' },
    { id: 'verify', label: 'Verify' },
    { id: 'complete', label: 'Complete missing items' },
    { id: 'submit', label: 'Submit / Track' },
  ];
  const customerStageIndex = stageForStep(currentStep?.id);

  return (
    <div className="mx-auto max-w-3xl px-5 py-6 sm:px-8">
      <div className="mb-4 flex items-center justify-between">
        <Link to="/cases" className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-500 hover:text-slate-900"><ChevronLeft size={16} /> My Cases</Link>
        <span className="text-xs text-slate-400">{cv?.snapshot?.country || caseRow?.destination} · {cv?.snapshot?.journey || caseRow?.journey}</span>
      </div>

      <div className="mb-3 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-slate-950">{ctx.state_label || 'Application'}</h1>
          <p className="text-xs text-slate-400">Stage {customerStageIndex + 1} of 4</p>
        </div>
        <div className="text-right text-xs text-slate-500">
          <p>Next:</p>
          <p className="font-medium text-slate-800">{ctx.next_action?.label}</p>
        </div>
      </div>

      <WizardProgress steps={customerStages} currentIndex={customerStageIndex} blockedStepId={blockedStepId} />

      <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        {renderStep()}
        {error && <p className="mt-4 flex items-center gap-2 rounded-lg bg-rose-50 p-3 text-sm text-rose-700"><AlertCircle size={14} /> {error}</p>}
      </div>

      {!isTerminal && (
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button onClick={onBack} disabled={isFirst} className="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 disabled:opacity-40"><ChevronLeft size={16} /> Back</button>
            <button onClick={onExit} disabled={busy} className="inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium text-slate-500 hover:bg-slate-50"><Save size={14} /> Save & exit</button>
          </div>
          {!last ? (
            <button onClick={onContinue} disabled={busy} className="inline-flex items-center gap-1.5 rounded-lg bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 disabled:opacity-50">{busy ? <Loader2 size={16} className="animate-spin" /> : <ChevronRight size={16} />} Continue</button>
          ) : (
            <Link to="/cases" className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800">Done</Link>
          )}
        </div>
      )}
      {isTerminal && (
        <div className="mt-4 flex justify-end">
          <Link to="/cases" className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800">Back to My Cases</Link>
        </div>
      )}
    </div>
  );
}

function ErrorState({ message, onRetry }) {
  return (
    <div className="mx-auto max-w-md px-5 py-20 text-center">
      <AlertCircle className="mx-auto h-8 w-8 text-rose-500" />
      <p className="mt-3 text-sm text-slate-600">{message}</p>
      <button onClick={onRetry} className="mt-4 inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"><RotateCw size={14} /> Try again</button>
    </div>
  );
}