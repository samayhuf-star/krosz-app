import { useState } from 'react';
import { UploadCloud, Loader2, ShieldCheck, AlertTriangle, CheckCircle2, Link2 } from 'lucide-react';
import {
  uploadPrivateDocument, createDocument, replaceDocument, attachDocument,
  getDocumentIntelligence, confirmDocumentExtraction, accountUpdateTraveler, addPassport,
  validateApplicationDocuments, evaluateMvpEngine, recordDocumentEngineResult,
} from '@/lib/visaApi';
import { inspectPassportImage, createEnhancedPassportScan } from '@/lib/passportImage';

const FIELD_LABELS = {
  surname: 'Surname', given_names: 'Given names', passport_number: 'Passport number',
  nationality: 'Nationality', date_of_birth: 'Date of birth', sex: 'Sex',
  place_of_birth: 'Place of birth', issue_date: 'Issue date', expiry_date: 'Expiry date',
  issuing_country: 'Issuing country',
};
const PROFILE_FIELDS = new Set(['surname', 'given_names', 'nationality', 'date_of_birth', 'sex']);

export default function PassportAutopilot({ caseRow, ctx, form, setForm, onReadyChange }) {
  const travelerId = ctx?.case_view?.traveler_id;
  const [busy, setBusy] = useState(false);
  const [quality, setQuality] = useState(null);
  const [intel, setIntel] = useState(null);
  const [versionId, setVersionId] = useState('');
  const [documentId, setDocumentId] = useState('');
  const [enhance, setEnhance] = useState(true);
  const [fields, setFields] = useState(/** @type {Record<string, string>} */ ({}));
  const [error, setError] = useState('');
  const [confirmed, setConfirmed] = useState(false);

  const loadIntel = async (id, initial) => {
    const result = initial?.extractions ? initial : await getDocumentIntelligence(id);
    setIntel(result);
    const next = /** @type {Record<string, string>} */ ({});
    for (const item of result?.extractions || []) next[item.field_name] = item.normalized_value || item.field_value || '';
    setFields(next);
    const needsReview = result?.intelligence?.status !== 'ready' || (result?.findings || []).some((f) => f.blocking && !f.resolved);
    onReadyChange?.(!needsReview);
    return result;
  };

  const upload = async (file) => {
    if (!file || !travelerId) return;
    setBusy(true); setError(''); setConfirmed(false);
    try {
      // Run the local quality inspection and upload concurrently. Neither depends
      // on the other, so this removes one full client-side wait from the hot path.
      const [report, originalUri] = await Promise.all([
        inspectPassportImage(file),
        uploadPrivateDocument(file),
      ]);
      setQuality(report);
      const created = await createDocument({
        traveler_id: travelerId,
        document_type: 'PASSPORT',
        display_name: file.name,
        storage_uri: originalUri,
        mime_type: file.type || 'application/octet-stream',
        file_size: file.size,
      });
      let activeVersion = created.version_id || created.version?.id;
      let activeDocument = created.document_id || created.document?.id;
      let intelligence = created.intelligence;

      // Enhancement is a fallback, not the default hot path. A clean original is
      // already the best OCR/MRZ source and avoids a second upload + replacement.
      if (enhance && report.canEnhance && report.checks?.length > 0) {
        const derivative = await createEnhancedPassportScan(file);
        if (derivative) {
          const derivativeUri = await uploadPrivateDocument(derivative);
          const replaced = await replaceDocument({
            document_id: activeDocument,
            storage_uri: derivativeUri,
            mime_type: derivative.type,
            file_size: derivative.size,
            source_version_id: activeVersion,
            derivative_kind: 'ENHANCED_SCAN',
            transformation: { crop: 'none_full_frame_preserved', contrast: 1.12, brightness: 1.03, perspective: 'not_applied' },
          });
          activeVersion = replaced.version_id || replaced.version?.id;
          intelligence = replaced.intelligence;
        }
      }

      // Attach and persist deterministic quality metadata in parallel; neither is
      // required before we can render extraction results returned by create/replace.
      const attachPromise = attachDocument({ application_id: caseRow.id, document_id: activeDocument, document_version_id: activeVersion });
      // Persist deterministic image-quality checks into Document Intelligence so
      // readiness cannot disagree with the upload UI. Passport field/MRZ checks
      // remain owned by the existing intelligence + review engines.
      const passportQualityResult = await evaluateMvpEngine('passport_intelligence', {
        passport: { surname: 'QUALITY_ONLY', given_names: 'QUALITY_ONLY', passport_number: 'QUALITY_ONLY', nationality: 'IND', date_of_birth: '2000-01-01', expiry_date: '2099-01-01' },
        mrz: { detected: true, valid: true }, quality: report,
        travel_start: caseRow?.travel_start || new Date().toISOString().slice(0, 10),
        policy: { min_validity_months: 0, policy_version: 'QUALITY-ONLY' }, conflicts: [],
      });
      const qualityOnly = { ...passportQualityResult, checks: (passportQualityResult.checks || []).filter((x) => x.check_id === 'PASS-008') };
      const qualityPromise = recordDocumentEngineResult(activeVersion, 'passport_image_quality', qualityOnly, caseRow.id);
      setVersionId(activeVersion); setDocumentId(activeDocument);
      // Show extracted passport fields as soon as intelligence is available. The
      // non-UI-critical persistence/validation work finishes concurrently.
      const intelPromise = loadIntel(activeVersion, intelligence);
      await Promise.all([
        intelPromise,
        attachPromise,
        qualityPromise,
      ]);
      validateApplicationDocuments(caseRow.id).catch(() => {});
    } catch (e) {
      setError(e?.message || 'We could not process this passport. The original has not been silently changed.');
      onReadyChange?.(false);
    } finally { setBusy(false); }
  };

  const confirm = async () => {
    if (!versionId) return;
    setBusy(true); setError('');
    try {
      const confirmation = await confirmDocumentExtraction(versionId, fields);
      const stillNeedsReview = confirmation?.intelligence?.status !== 'ready';
      const nameParts = String(fields.given_names || '').trim().split(/\s+/);
      const travelerPatch = {
        first_name: nameParts.shift() || undefined,
        middle_name: nameParts.join(' ') || undefined,
        last_name: fields.surname || undefined,
        date_of_birth: fields.date_of_birth || undefined,
        nationality: fields.nationality || undefined,
        gender: fields.sex === 'M' ? 'male' : fields.sex === 'F' ? 'female' : undefined,
        metadata: { passport_prefill: { document_id: documentId, version_id: versionId, confirmed_at: new Date().toISOString() } },
      };
      await accountUpdateTraveler(travelerId, Object.fromEntries(Object.entries(travelerPatch).filter(([, v]) => v !== undefined)));
      if (fields.passport_number) {
        await addPassport(travelerId, {
          passport_number: fields.passport_number, country: fields.issuing_country || fields.nationality,
          surname: fields.surname || '', given_names: fields.given_names || '', nationality: fields.nationality || '',
          date_of_birth: fields.date_of_birth || undefined, issue_date: fields.issue_date || undefined,
          expiry_date: fields.expiry_date || undefined, sex: fields.sex || undefined,
          verification_status: 'verified', confidence: 1, source: 'extraction',
        }).catch(() => {});
      }
      setForm({ ...form, traveler_info: { ...(form.traveler_info || {}), first_name: travelerPatch.first_name, last_name: travelerPatch.last_name, dob: fields.date_of_birth, passport_number: fields.passport_number }, passport: { version_id: versionId, confirmed: !stillNeedsReview } });
      setConfirmed(!stillNeedsReview); onReadyChange?.(!stillNeedsReview);
      await validateApplicationDocuments(caseRow.id).catch(() => {});
      // Always refresh intelligence after confirmation so the UI reflects the
      // reconciled findings (remediated blockers are now resolved server-side).
      const refreshed = await loadIntel(versionId);
      if (stillNeedsReview) {
        // Surface the ACTUAL remaining blocking issues instead of a generic
        // "image-quality or consistency issue" message, so the traveler knows
        // exactly what to fix or re-upload.
        const blockers = (refreshed?.findings || []).filter((f) => f.blocking && !f.resolved);
        const detail = blockers.length
          ? blockers.slice(0, 3).map((f) => f.message).join(' · ')
          : 'an image-quality or consistency issue still needs review';
        setError(`Your corrections were saved, but ${detail}.`);
      }
    } catch (e) { setError(e?.message || 'Could not save your confirmation.'); }
    finally { setBusy(false); }
  };

  const extractions = intel?.extractions || [];
  const blocking = (intel?.findings || []).filter((f) => f.blocking && !f.resolved);
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-emerald-200 bg-emerald-50/50 p-4">
        <h3 className="text-base font-semibold text-slate-950">Start with your passport</h3>
        <p className="mt-1 text-sm text-slate-600">Upload the photo page. We’ll check image quality, read available details, and ask you to review only uncertain fields.</p>
        <label className="mt-4 flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-emerald-300 bg-white px-4 py-5 text-center focus-within:ring-2 focus-within:ring-emerald-500">
          {busy ? <Loader2 className="h-6 w-6 animate-spin text-emerald-600" /> : <UploadCloud className="h-6 w-6 text-emerald-600" />}
          <span className="mt-2 text-sm font-semibold text-slate-800">Upload passport photo or scan</span>
          <span className="text-xs text-slate-500">JPG, PNG or PDF · up to 10 MB</span>
          <input aria-label="Upload passport photo or scan" type="file" accept="image/jpeg,image/png,application/pdf" className="sr-only" disabled={busy} onChange={(e) => upload(e.target.files?.[0])} />
        </label>
        <label className="mt-3 flex items-start gap-2 text-xs text-slate-600">
          <input type="checkbox" checked={enhance} onChange={(e) => setEnhance(e.target.checked)} className="mt-0.5" />
          <span>Create a clearer scan copy when possible. Your original remains preserved and the enhanced copy is linked with its transformation history.</span>
        </label>
        <button type="button" disabled className="mt-3 inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-500" aria-describedby="digilocker-note"><Link2 size={14} /> Import from DigiLocker · Coming soon</button>
        <p id="digilocker-note" className="mt-1 text-[11px] text-slate-500">Connection-ready only. No DigiLocker data is accessed until requester credentials and OAuth approval are configured.</p>
      </div>

      {quality && <div className="rounded-xl border border-slate-200 p-3" aria-live="polite">
        <p className="flex items-center gap-2 text-sm font-medium text-slate-800">{quality.checks?.length ? <AlertTriangle size={15} className="text-amber-600" /> : <CheckCircle2 size={15} className="text-emerald-600" />} Image quality</p>
        {quality.checks?.length ? <ul className="mt-2 list-disc space-y-1 pl-5 text-xs text-amber-800">{quality.checks.map((c) => <li key={c.code}>{c.message}</li>)}</ul> : <p className="mt-1 text-xs text-emerald-700">Basic quality checks passed.</p>}
      </div>}

      {extractions.length > 0 && <div className="rounded-xl border border-slate-200 p-4">
        <div className="flex items-center justify-between gap-3"><h3 className="text-sm font-semibold text-slate-900">Verify passport details</h3><span className="text-xs text-slate-500">Edit anything that is wrong</span></div>
        <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {extractions.filter((x) => FIELD_LABELS[x.field_name]).map((item) => {
          const low = Number(item.confidence || 0) < 0.9 || item.source !== 'mrz';
          return (
            <label key={item.field_name} className="block">
              <span className="mb-1 block text-xs font-medium text-slate-600">{FIELD_LABELS[item.field_name]}</span>
              <input value={fields[item.field_name] || ''} onChange={(e) => setFields({ ...fields, [item.field_name]: e.target.value })}
                className={`w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-500 ${low ? 'border-amber-300 bg-amber-50/30' : 'border-slate-200'}`} />
            </label>
          );
          })}
        </div>
        {blocking.length > 0 && <p className="mt-3 rounded-lg bg-amber-50 p-3 text-xs text-amber-800">{blocking.length} issue{blocking.length === 1 ? '' : 's'} need confirmation before we can continue.</p>}
        <button type="button" onClick={confirm} disabled={busy || confirmed} className="mt-4 inline-flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"><ShieldCheck size={15} /> {confirmed ? 'Confirmed and saved' : 'Confirm and save to traveler profile'}</button>
      </div>}
      {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
    </div>
  );
}